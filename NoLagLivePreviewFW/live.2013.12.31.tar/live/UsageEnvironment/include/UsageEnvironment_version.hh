// Version information for the "UsageEnvironment" library
// Copyright (c) 1996-2013 Live Networks, Inc.  All rights reserved.

#ifndef _USAGEENVIRONMENT_VERSION_HH
#define _USAGEENVIRONMENT_VERSION_HH

#define USAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2013.12.31"
#define USAGEENVIRONMENT_LIBRARY_VERSION_INT		1388448000

#endif
